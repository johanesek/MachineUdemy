﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Configuration;
using System.IO;
using System.Collections.Generic;

namespace COSManager
{
    /// <summary>
    /// This is the main application class, which executes the individual functions.
    /// </summary>
    public class Program
    {
        static internal BooleanSwitch TraceEnabled;

        /// <summary>
        /// Function, which will be called, when COSManager.exe is started from command line.
        /// No Arguments are necessary.
        /// </summary>
        [STAThread]
        static int Main(string[] args)
        {
            int result = 0;
            FileStream log = null;
            var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
            if (windowsIdentity != null)
            {
                string sUserName = windowsIdentity.Name;
               
                //Read protocol option from configuration file, which is either "Console" or "File"
                //All remaining protocol entries will be directed to the chosen output destination
                string sProtocolFile = ConfigurationManager.AppSettings["ProtocolFile"];

                if (ConfigurationManager.AppSettings["ProtocolType"].ToUpper() == "CONSOLE")
                {
                    Trace.Listeners.Add(new TextWriterTraceListener(Console.Out));
                }
                else if (ConfigurationManager.AppSettings["ProtocolType"].ToUpper() == "FILE")
                {
                    log = new FileStream(sProtocolFile, FileMode.Create);
                    Trace.Listeners.Add(new TextWriterTraceListener(log));
                }
                else
                {
                    Console.WriteLine("Invalid ProtocolType: " + ConfigurationManager.AppSettings["ProtocolType"]);
                    return 0;
                }

                //Check, whether tracing is enabled in application configuration
                TraceEnabled = new BooleanSwitch("TraceEnabled", "tracing on/off");

                //Creating instance of DataLayer class, which contains data access logic to SQL Server and TeraData
                DataLayer myDataLayer = new DataLayer();

                try
                {
                    //Retrieving user information from TeraData and Active Directory and populate internal list of all users and SQL Server table with additional user data
                    Trace.WriteLineIf(TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + sUserName + "\t" + "Retrieving user information from Teradata...");
                    //posible improvement of speed
                    List<Person> userList = myDataLayer.GetUserInformation();
                    
                    //if list of users is not empty, continue with populating the Repository
                    if (userList.Count > 0)
                    {
                        //Creating instance of COSLayer class, which contains all functions to update the Repository
                        COSLayer myCosLayer = new COSLayer(userList, myDataLayer.RoleMapping, myDataLayer.ReportCatalogRoles, myDataLayer.CompanyNumber);

                        //Connecting to Repository
                        Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Connecting to Repository...");
                        if (myCosLayer.Connect())
                        {
                            //Rfreshing MGMT roles based on company mapping
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Refreshing MGMT Adjust. roles based on company mapping...");
                            myCosLayer.RefreshMGMTAdjustRolesRoles(myDataLayer.CompanyMapping);

                            //Exporting additional user data to SQL Server table
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Exporting FIM data to SQL Server table...");
                            myDataLayer.ExportFIMData();

                            //Exporting additional user data to SQL Server table
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Exporting user data to SQL Server table...");
                            myDataLayer.ExportUserData(userList);

                            //Removing Windows users from OLAP roles in OLAP permission management
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Removing OLAP role assignments...");
                            myCosLayer.DeleteOLAPRoleAssignments();

                            //Removing Windows users from user management in Repository
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Removing SSO user...");
                            myCosLayer.DeleteSSOUser();

                            //Registering Windows users in user management of Repository
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Creating SSO users...");
                            myCosLayer.CreateSSOUser();

                            //Creating OLAP roles for business units and trade clusters
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Creating OLAP roles...");
                            myCosLayer.CreateAleaRoles();

                            //Assigning Windows users to OLAP roles
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Assigning Windows user to OLAP roles...");
                            myCosLayer.AssignOLAPRoles();

                            //Assigning OLAP permissions (write, import/export) to OLAP roles
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Assigning OLAP permissions to OLAP roles...");
                            myCosLayer.AssignPermissions();

                            //Disconnecting from Repository
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Disconnecting from Repository...");
                            myCosLayer.Disconnect();

                            //Connecting to OLAP Server
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Connecting to OLAP Server...");
                            OLAPLayer oOLAPLayer = new OLAPLayer(ConfigurationManager.AppSettings["OLAPDB"], ConfigurationManager.AppSettings["OLAPUser"], ConfigurationManager.AppSettings["OLAPPwd"]);

                            //Updating OLAP dimension User
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Updating OLAP dimension User...");
                            oOLAPLayer.UpdateUserDimension(userList);

                            //Refreshing roles in OLAP Server
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Refreshing roles in OLAP Server...");
                            oOLAPLayer.RefreshRoles();

                            //Updating dimension access cube 
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Updating dimension access cube for dimensions...");
                            oOLAPLayer.FillDACAllRoles(myDataLayer, myCosLayer.OlapRoles, myDataLayer.OlapRolesExceptionList);

                            //Disconnecting from OLAP Server
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Disconnecting from OLAP Server...");
                            oOLAPLayer.Disconnect();

                            //Close protocol file if option is enabled
                            Trace.Flush();
                            if (ConfigurationManager.AppSettings["ProtocolType"].ToUpper() == "FILE")
                            {
                                if (log != null) { log.Close(); }
                            }

                            //Execution was successful, return value of 1
                            result = 1;
                        }
                        else
                        {
                            //Connection to Repository failed
                            Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Connection to Repository failed.");

                            //Close protocol file if option is enabled
                            Trace.Flush();
                            if (ConfigurationManager.AppSettings["ProtocolType"].ToUpper() == "FILE")
                            {
                                if (log != null) { log.Close(); }
                            }

                            //Execution failed, return value of 0
                            result = 0;
                        }

                    }
                    else
                    {
                        //Retrieving of user list from TeraData failed
                        Trace.WriteLineIf(TraceEnabled.Enabled, DateTime.Now + "\t" + sUserName + "\t" + "Retrieving of user list from TeraData failed.");

                        //Close protocol file if option is enabled
                        Trace.Flush();
                        if (ConfigurationManager.AppSettings["ProtocolType"].ToUpper() == "FILE")
                        {
                            if (log != null) { log.Close(); }
                        }

                        //Execution failed, return value of 0
                        result = 0;
                    }
                }
                finally
                {
                }
            }
            return result;
        }
    }
}
