using System;
using System.DirectoryServices;
using System.Configuration;
using System.Management;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;

namespace COSManager
{
    /// <summary>
    /// This class is a layer for Active Directory access.
    /// </summary>
    public class DomainQuery
    {
        public string GetLdapFilterUSer(string sUserName)
        {
            return "(samaccountName=" + sUserName.Substring(sUserName.IndexOf("\\") + 1).ToLower() + ")";
        }
        /// <summary>
        /// This method retrieves additional properties for a given user from Active Directory.
        /// </summary>
        public List<Person> GetWindowsUserProperties(string ldapUsersFilter)
        {
            List<Person> propertiesList = new List<Person>();
            //Retrieving application settings
            string sNamingContext = ConfigurationManager.AppSettings["NamingContext"];

            string sDomainUser = ConfigurationManager.AppSettings["WindowsDomainUser"];// binding user with sufficient privileges
            string sDomainPwd = ConfigurationManager.AppSettings["WindowsDomainPwd"]; // password of the binding user
            string sADSIProvider = ConfigurationManager.AppSettings["ADSIProvider"];
            string prop = String.Empty;

            try
            {
                //Creating new instance of .NET DirectoryEntry class
                DirectoryEntry dEntry = new DirectoryEntry(sADSIProvider + "://" + sNamingContext, sDomainUser, sDomainPwd, AuthenticationTypes.Secure);

                //Creating new instance of .NET DirectorySearcher class
                DirectorySearcher mySearcher = new DirectorySearcher(dEntry)
                {
                    Filter =
                        ("(&(objectClass=user)(objectCategory=person)(|" + ldapUsersFilter + "))")
                };

                //Specifying the filter criteria for the Active Directory query

                //Specifying required properties, which should be retrieved
                mySearcher.PropertiesToLoad.Add("co");
                mySearcher.PropertiesToLoad.Add("company");
                mySearcher.PropertiesToLoad.Add("department");
                mySearcher.PropertiesToLoad.Add("sn");
                mySearcher.PropertiesToLoad.Add("givenName");
                mySearcher.PropertiesToLoad.Add("cn");
                mySearcher.PropertiesToLoad.Add("objectSid");
                mySearcher.PropertiesToLoad.Add("samaccountName");

                //Converting result into usable format
                SearchResultCollection resultAll = mySearcher.FindAll();
                foreach (var item in resultAll)
                {
                    try
                    {
                        SearchResult result = item as SearchResult;
                        if (result == null)
                        {
                            continue;
                        }
                        ResultPropertyValueCollection sCountry = result.Properties["co"];
                        ResultPropertyValueCollection sCompany = result.Properties["company"];
                        ResultPropertyValueCollection sDepartment = result.Properties["department"];
                        ResultPropertyValueCollection sFirstName = result.Properties["givenName"];
                        ResultPropertyValueCollection sLastName = result.Properties["sn"];
                        ResultPropertyValueCollection userSid = result.Properties["objectSid"];
                        ResultPropertyValueCollection userName = result.Properties["samaccountName"];

                        Person properties = new Person();
                        //Handing back of properties according to provided output type
                        properties.UserID = userName[0].ToString();
                        properties.Country = sCountry[0].ToString();
                        if (sCompany.Count > 0)
                        {
                            properties.Company = sCompany[0].ToString();
                        }
                        else
                        {
                            properties.Company = "-";
                        }
                        if (sDepartment.Count > 0)
                        {
                            properties.Department = sDepartment[0].ToString();
                        }
                        else
                        {
                            properties.Department = "-";
                        }
                        properties.Name = sFirstName[0].ToString() + " " + sLastName[0].ToString();

                        if (null != userSid)
                        {
                            properties.UserSid = ConvertByteToStringSid((Byte[])userSid[0]);
                        }
                        else
                        {
                            properties.UserSid = String.Empty;
                        }
                        propertiesList.Add(properties);
                    }
                    catch (Exception ex)
                    {
                        string sLogText = "Retrieving of additional properties for Windows useres failed: " + ex.Message;
                        Trace.WriteLineIf(Program.TraceEnabled.Enabled, sLogText);
                    }
                }

            }
            catch (Exception ex)
            {
                string sLogText = "Retrieving of additional properties for Windows useres failed: " + ex.Message;
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, sLogText);
            }
            return propertiesList;
        }

        /// <summary>
        /// This is a helper function implementing a conversion from an AD query result to a readable format.
        /// </summary>
        private string ConvertByteToStringSid(Byte[] sidBytes)
        {
            StringBuilder strSid = new StringBuilder();
            strSid.Append("S-");
            try
            {
                // Add SID revision.
                strSid.Append(sidBytes[0].ToString());
                // Next six bytes are SID authority value.
                if (sidBytes[6] != 0 || sidBytes[5] != 0)
                {
                    string strAuth = string.Format
                        ("0x{0:2x}{1:2x}{2:2x}{3:2x}{4:2x}{5:2x}",
                        (Int16)sidBytes[1],
                        (Int16)sidBytes[2],
                        (Int16)sidBytes[3],
                        (Int16)sidBytes[4],
                        (Int16)sidBytes[5],
                        (Int16)sidBytes[6]);
                    strSid.Append("-");
                    strSid.Append(strAuth);
                }
                else
                {
                    Int64 iVal = (Int32)(sidBytes[1]) +
                        (Int32)(sidBytes[2] << 8) +
                        (Int32)(sidBytes[3] << 16) +
                        (Int32)(sidBytes[4] << 24);
                    strSid.Append("-");
                    strSid.Append(iVal.ToString());
                }

                // Get sub authority count...
                int iSubCount = Convert.ToInt32(sidBytes[7]);
                for (int i = 0; i < iSubCount; i++)
                {
                    int idxAuth = 8 + i * 4;
                    UInt32 iSubAuth = BitConverter.ToUInt32(sidBytes, idxAuth);
                    strSid.Append("-");
                    strSid.Append(iSubAuth.ToString());
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, ex.Message);
                strSid.Clear();
            }
            return strSid.ToString();
        }
    }

}
