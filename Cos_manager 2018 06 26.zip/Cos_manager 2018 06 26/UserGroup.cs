﻿using System.Collections;
using System.Collections.Generic;

namespace COSManager
{
    /// <summary>
    /// This class is a helper class to store user group information.
    /// </summary>
    public class UserGroup
    {
        public string Name { get; set; }
        public List<string> Companies { get; set; }
        public List<string> MaerskStrings { get; set; }
        public List<string> TradeCluster { get; set; }

        /// <summary>
        /// This constructor method retrieves usergroup data from configuration file.
        /// </summary>
        public UserGroup(string strUserGroup)
        {
            Name = strUserGroup;
        }
    }
}
