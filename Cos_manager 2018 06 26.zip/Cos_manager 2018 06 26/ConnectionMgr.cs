using System;
using System.Diagnostics;
using System.Data.SqlClient;
using Teradata.Client.Provider;


namespace COSManager
{
	/// <summary>
	/// This class is a helper class to establish and close database connections to SQL Server or TeraData.
	/// </summary>
	public class ConnectionMgr
	{

		private ConnectionMgr()
		{
		}

		/// <summary>
		/// The purpose of this method is to establish connection to an TeraData database.
		/// </summary>
        public static TdConnection GetTdDbConnection(string username, string password, string connectString, string initialCatalog) 
		{
            TdConnection conn = null;
			try
			{
				// Connection Information	
                string connectionString =
                    // Username
                    "User Id=" + username +
                    // Password
                    ";Password=" + password +
                    // Datasource  
                    ";Data Source=" + connectString;
					//Initial Catalog: not used for Teradata
                    //";Initial Catalog=" + initialCatalog;

				// Create Connection object using the above connect string
				conn = new TdConnection(connectionString);

				// Open database connection
				conn.Open();
			}
			catch (Exception ex) 
			{
				Trace.WriteLineIf(Program.TraceEnabled.Enabled, "Connection to TeraData failed: " + ex.Message);
                conn = null;
			}

            return conn;
		}

		/// <summary>
		/// The purpose of this method is to close the TeraData database connection 
		/// </summary>
		public static void CloseTdConnection(TdConnection connTd)
		{
			try
			{
				if (connTd != null)
				{
					connTd.Close();
					connTd.Dispose();
				}
			}
			catch (Exception ex) 
			{
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, "Unable to close TeraData connection: " + ex.Message);
            }
		}

        /// <summary>
        /// The purpose of this method is to establish connection to a SQL Server database.
        /// </summary>
        public static SqlConnection GetSqlDbConnection(string username, string password, string connectString, string initialCatalog)
        {
            SqlConnection conn = null;
            try
            {
                // Connection Information	
                string connectionString =
                    // Username
                    "User Id=" + username +
                    // Password
                    ";Password=" + password +
                    // Datasource  
                    ";Data Source=" + connectString +
                    //Initial Catalog
                    ";Initial Catalog=" + initialCatalog;

                // Create Connection object using the above connect string
                conn = new SqlConnection(connectionString);

                // Open database connection
                conn.Open();
            }
            catch (Exception ex)
            {
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, "Connection to SQL Server failed: " + ex.Message);
                conn = null;
            }

            return conn;
        }

        /// <summary>
        /// The purpose of this method is to close the SQL Server database connection 
        /// </summary>
        public static void CloseSqlConnection(SqlConnection connSql)
        {
            try
            {
                if (connSql != null)
                {
                    connSql.Close();
                    connSql.Dispose();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, "Unable to close SQL Server connection: " + ex.Message);
            }
        }
	}
}
