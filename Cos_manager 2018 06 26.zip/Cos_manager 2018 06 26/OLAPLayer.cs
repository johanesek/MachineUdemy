﻿using System;
using MdsAut;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Specialized;
using System.IO;
using System.Collections;
using System.Collections.Generic;

namespace COSManager
{
    /// <summary>
    /// This class is a layer for OLAP Server data access.
    /// </summary>
    public class OLAPLayer
    {
        private MdsAut.General _OLAPGeneral;
        private MdsAut.Servers _OLAPServer;
        private string _sServer;
        private string _sUserName;
        private string _sUserDimension;
        private string _sUserHierachy;
        public ListDictionary OperatorMapping { get; set; }

        private const string CsTradeClusterPrefix = "TC_";

        private const string CsXmlCmdRefreshRoles = "<?xml version=\"1.0\"?>" +
                                                        "<Alea:Document xmlns:Alea=\"http://www.misag.com\">" +
                                                            "<Alea:Request RequestID=\"001\" Class=\"Database\" Method=\"UpdateRoles\">" +
                                                            "</Alea:Request>" +
                                                        "</Alea:Document>";
        /// <summary>
        /// This is the constructor method.
        /// OLAP Server connection is being initialized here.
        /// </summary>
        public OLAPLayer(string sServer, string sUser, string sPwd)
        {
            _sServer = sServer;

            _OLAPGeneral = new General();
            _OLAPGeneral.MdsInit(-1);

            _OLAPServer = new Servers();
            _OLAPServer.ServerConnectEx(sServer, sUser, sPwd);

            var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
            if (windowsIdentity != null)
            {
                _sUserName = windowsIdentity.Name;
            }

            _sUserDimension = ConfigurationManager.AppSettings["FIMUserDimension"].ToString();
            _sUserHierachy = ConfigurationManager.AppSettings["FIMUserHierarchy"].ToString();

            OperatorMapping = new ListDictionary();

            Array asTemp = ConfigurationManager.AppSettings["VesselOperatorMapping"].Split('|');
            for (int i = 0; i <= asTemp.Length - 1; i++)
            {
                string[] opr = asTemp.GetValue(i).ToString().Split(',');
                OperatorMapping.Add(opr[0], opr[1]);
            }
        }

        /// <summary>
        /// This method is closing the database connection to OLAP Server.
        /// </summary>
        public void Disconnect()
        {
            _OLAPServer.ServerDisconnect(_sServer);

            _OLAPGeneral.MdsClose(-1);
        }

        /// <summary>
        /// This method is populating the dimension access cube for a single OLAP user role.
        /// The write right for this role is being assigned to all child elements of a particular root element.
        /// This root element is being derived from the user role.
        /// Hierarchy information is being extracted from a SQL Server table in database FBR_DSA_Transfer.
        /// </summary>
        /// <param name="dataLayer"></param>
        /// <param name="olapRoles"></param>
        /// <param name="olapRolesExceptionList"></param>
        public void FillDACAllRoles(DataLayer dataLayer, List<string> olapRoles, List<string> olapRolesExceptionList)
        {
            string crtrole = String.Empty;
            if (dataLayer == null)
            {
                return;
            }

            MdsAut.DataCells objDataCells = new DataCells();

            object vntWriteValue = 2;

            string sBulkErrorFile = ConfigurationManager.AppSettings["BulkErrorFile"];
            string sLog = String.Empty;

            using (SqlConnection connSql = dataLayer.GetSqlConnection())
            {
                using (StreamWriter oStream = new StreamWriter(sBulkErrorFile, false))
                {
                    SqlCommand insCmd = new SqlCommand();
                    SqlDataReader oReaderString = null;
                    SqlDataReader oReaderVessel = null;

                    try
                    {
                        insCmd.Connection = connSql;

                        objDataCells.BulkTransferBegin(Convert.ToInt32(MdsAut.Constants.mdsBulkDataPutValue));

                        string sCube = String.Empty;

                        foreach (string sRole in olapRoles)
                        {
                            crtrole = sRole;
                            if (!olapRolesExceptionList.Contains(sRole))
                            {
                                string sTradeCluster = CsTradeClusterPrefix + sRole.Substring(sRole.IndexOf("_") + 1);

                                //string
                                sCube = ConfigurationManager.AppSettings["StringDAC"];

                                string strSQL = GetSqlQueryForStringDimension(sRole, sTradeCluster, sCube);

                                if (!(sRole.IndexOf("ADJUST") > 0))
                                {
                                    //Executing the SQL query
                                    insCmd.CommandText = strSQL;
                                    oReaderString = insCmd.ExecuteReader();

                                    //Populating the internal user list based on the SQL query
                                    while (oReaderString.Read())
                                    {
                                        string buSameAsRole = oReaderString["BusinessUnit"].ToString().Substring(oReaderString["BusinessUnit"].ToString().IndexOf("_") + 1);

                                        string subString = String.Empty;
                                        if (sRole.IndexOf("_") > -1)
                                        {
                                            subString = sRole.Substring(0, sRole.IndexOf("_"));
                                        }
                                        if ((buSameAsRole == subString)
                                            || buSameAsRole == "Unknown" || (sRole == "FBR_SUPERUSER" || sRole == "ALL_STRINGS" || sRole == "FBR_SERVICE" || sRole == "FBR_DEVELOPER"))
                                        {
                                            string nextVal = oReaderString["String"].ToString();
                                            objDataCells.DataPutValue(_sServer,
                                                sCube,
                                                vntWriteValue,
                                                nextVal,
                                                sRole,
                                                null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null
                                                );
                                        }
                                    }

                                    if (oReaderString != null)
                                    {
                                        oReaderString.Close();
                                    }
                                }

                                //trade Company
                                sCube = ConfigurationManager.AppSettings["TradeContractDAC"];

                                
                                strSQL = GetSqlQueryForTradeDimensionCompany(sRole, sTradeCluster, sCube);

                                if (!(sRole.IndexOf("ADJUST") > 0))
                                {
                                    //Executing the SQL query
                                    insCmd.CommandText = strSQL;
                                    oReaderString = insCmd.ExecuteReader();

                                    //Populating the internal user list based on the SQL query
                                    while (oReaderString.Read())
                                    {
                                        string buSameAsRole = oReaderString["BusinessUnit"].ToString().Substring(oReaderString["BusinessUnit"].ToString().IndexOf("_") + 1);

                                        string subString = String.Empty;
                                        if (sRole.IndexOf("_") > -1)
                                        {
                                            subString = sRole.Substring(0, sRole.IndexOf("_"));
                                        }
                                        string nextVal = oReaderString["String"].ToString();
                                        objDataCells.DataPutValue(_sServer,
                                            sCube,
                                            vntWriteValue,
                                            nextVal,
                                            sRole,
                                            null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null
                                            );
                                    }

                                    if (oReaderString != null)
                                    {
                                        oReaderString.Close();
                                    }
                                }


                                //trade Market
                                sCube = ConfigurationManager.AppSettings["TradeDAC"];

                                strSQL = GetSqlQueryForTradeDimensionMarket(sRole, sTradeCluster, sCube);

                                if (!(sRole.IndexOf("ADJUST") > 0))
                                {
                                    //Executing the SQL query
                                    insCmd.CommandText = strSQL;
                                    oReaderString = insCmd.ExecuteReader();

                                    //Populating the internal user list based on the SQL query
                                    while (oReaderString.Read())
                                    {
                                        string buSameAsRole = oReaderString["BusinessUnit"].ToString().Substring(oReaderString["BusinessUnit"].ToString().IndexOf("_") + 1);

                                        string subString = String.Empty;
                                        if (sRole.IndexOf("_") > -1)
                                        {
                                            subString = sRole.Substring(0, sRole.IndexOf("_"));
                                        }
                                        string nextVal = oReaderString["String"].ToString();
                                        objDataCells.DataPutValue(_sServer,
                                            sCube,
                                            vntWriteValue,
                                            nextVal,
                                            sRole,
                                            null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null
                                            );
                                    }

                                    if (oReaderString != null)
                                    {
                                        oReaderString.Close();
                                    }
                                }

                                //Vessel
                                sCube = ConfigurationManager.AppSettings["VesselDAC"];

                                if (sRole.IndexOf("_") > 0 && sRole != "FBR_VIEWER" && sRole != "FBR_TESTER")
                                {
                                    strSQL = GetSqlQueryForVesselDimension(sRole);

                                    //Executing the SQL query
                                    insCmd.CommandText = strSQL;
                                    oReaderVessel = insCmd.ExecuteReader();

                                    while (oReaderVessel.Read())
                                    {
                                        string nextVal = oReaderVessel["Vessel"].ToString();
                                        objDataCells.DataPutValue(_sServer,
                                            sCube,
                                            vntWriteValue,
                                            nextVal,
                                            sRole,
                                            null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null
                                            );
                                    }

                                    if (oReaderVessel != null)
                                    {
                                        oReaderVessel.Close();
                                    }
                                }
                            }
                        }

                        if (String.Compare(sLog, String.Empty) != 0)
                        {
                            oStream.Write(sLog);
                            oStream.Flush();
                        }

                        objDataCells.BulkTransferCommit(Convert.ToInt32(MdsAut.Constants.mdsBulkDataPutValue), false, out sLog);

                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + crtrole + "\t" + ex.Message);

                        if (objDataCells != null && objDataCells.BulkTransferIsActive(Convert.ToInt32(MdsAut.Constants.mdsBulkDataPutValue)))
                        {
                            objDataCells.BulkTransferAbort(Convert.ToInt32(MdsAut.Constants.mdsBulkDataPutValue));
                        }
                        if (oReaderVessel != null)
                        {
                            oReaderVessel.Close();
                        }
                        if (oReaderString != null)
                        {
                            oReaderString.Close();
                        }
                    }
                    finally
                    {
                        connSql.Close();
                    }
                }
            }
        }

        /// <summary>
        /// This method is updating the OLAP dimension User, which consists of all Windows user id's in a flat hierarchy.
        /// Due to technical reasons only non-existing users are being created. No user will be removed by this function.
        /// </summary>
        public void UpdateUserDimension(List<Person> userList)
        {
            MdsAut.Dimensions objDimensions = new Dimensions();
            MdsAut.Elements objElements = new Elements();
            string sElementType = String.Empty;
            Array asElements = null;

            try
            {
                //remove existing dimension items under hierarchy "FIM"
                objDimensions.DimensionEditBegin(_sServer, _sUserDimension, false);
                objElements.ElementChildrenGetArray(_sServer, _sUserDimension, _sUserHierachy, ref asElements);
                if (asElements == null)
                {
                    asElements = new Array[0];
                }
                else
                {
                    if (_OLAPGeneral.MdsGetLastError() > 0 && asElements.Length > 0)
                    {
                        throw new Exception(_OLAPGeneral.MdsError(Convert.ToInt32(_OLAPGeneral.MdsGetLastError())));
                    }
                }
                for (int i = 0; i < asElements.Length; i++)
                {
                    objDimensions.DimensionEditDelElement(_sServer, _sUserDimension, asElements.GetValue(i).ToString());
                }
                objDimensions.DimensionEditCommit(_sServer, _sUserDimension, true);

                //add new dimension items based on FIM
                objDimensions.DimensionEditBegin(_sServer, _sUserDimension, false);
                foreach (Person t in userList)
                {
                    try
                    {
                        objDimensions.DimensionEditAddElement(_sServer, _sUserDimension, "N", t.UserID, _sUserHierachy, 0);
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + ex.Message);
                    }
                }
                objDimensions.DimensionEditCommit(_sServer, _sUserDimension, true);
            }
            catch (Exception ex)
            {
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + ex.Message);
            }

        }

        /// <summary>
        /// This method is refreshing the OLAP user roles currently active in OLAP Server by executing a specific XML command of OLAP Server API.
        /// </summary>
        public void RefreshRoles()
        {
            try
            {
                _OLAPGeneral.xmlRequest(_sServer, CsXmlCmdRefreshRoles);

            }
            catch (Exception ex)
            {
                String errMsg;
                if (_OLAPGeneral.MdsGetLastError() > 0)
                {
                    errMsg = _OLAPGeneral.MdsError(_OLAPGeneral.MdsGetLastError());
                }
                else
                {
                    errMsg = ex.Message;
                }
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + errMsg);
            }
        }

        /// <summary>
        /// Return SQL query for specific role, trade cluster for Dimension String
        /// </summary>
        /// <param name="sRole"></param>
        /// <param name="sTradeCluster"></param>
        /// <param name="sCube"></param>
        /// <returns></returns>
        private string GetSqlQueryForStringDimension(string sRole, string sTradeCluster, string sCube)
        {
            string strSQL = String.Empty;
            if (sRole == "FBR_SUPERUSER" || sRole == "ALL_STRINGS" || sRole == "FBR_DEVELOPER" || sRole == "FBR_SERVICE")
            {
                sTradeCluster = "BU_";

                strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_String]  T1 ";
                strSQL += "INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_String] T2 ON T1.Parent = T2.Child AND T2.Distance = 0 ";
                strSQL += "WHERE T2.Parent like '" + sTradeCluster + "%' AND T2.Child = T1.Parent ";
                strSQL += "GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "UNION ALL SELECT 'BU All', 'BU All', 'All BU'";
                strSQL += "UNION ALL SELECT 'BU All', 'BU All', 'String_Unknown'";
                strSQL += "UNION ALL SELECT 'BU All', 'BU All', 'Unknown'";
            }
            else if (sRole.IndexOf("ALL") > 0)
            {
                sTradeCluster = "BU_" + sRole.Substring(0, sRole.IndexOf("_"));

                strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_String]  T1 ";
                strSQL += "INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_String] T2 ON T1.Parent = T2.Child AND T2.Distance = 0 ";
                strSQL += "WHERE T2.Parent like '" + sTradeCluster + "%' AND T2.Child = T1.Parent ";
                strSQL += "GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "UNION ALL SELECT 'String_Unknown', 'String_Unknown', 'String_Unknown'";
                strSQL += "UNION ALL SELECT 'String_Unknown', 'String_Unknown', 'Unknown'";
            }
            else
            {
                strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS TradeCluster, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_String]  T1 ";
                strSQL += "INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_String] T2 ON T1.Parent = T2.Child AND T2.Distance = 1 ";
                strSQL += "WHERE T1.Parent like '" + sTradeCluster + "%' AND T2.Child = T1.Parent ";
                strSQL += "GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "UNION ALL SELECT 'String_Unknown', 'String_Unknown', 'String_Unknown'";
                strSQL += "UNION ALL SELECT 'String_Unknown', 'String_Unknown', 'Unknown'";
            }
            return strSQL;
        }



        /// <summary>
        /// Return SQL query for specific role, trade cluster for Dimension String
        /// </summary>
        /// <param name="sRole"></param>
        /// <param name="sTradeCluster"></param>
        /// <param name="sCube"></param>
        /// <returns></returns>
        private string GetSqlQueryForTradeDimensionCompany(string sRole, string sTradeCluster, string sCube)
        {
            string sTrade = "";

            string strSQL = String.Empty;
            if (sRole == "FBR_SUPERUSER" || sRole == "ALL_STRINGS" || sRole == "FBR_DEVELOPER" || sRole == "FBR_SERVICE")
            {
                sTradeCluster = "BU_";

                strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]  T1 ";
                strSQL += "INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract] T2 ON T1.Parent = T2.Child AND T2.Distance = 0 ";
                strSQL += "WHERE T2.Parent like '" + sTradeCluster + "%' AND T2.Child = T1.Parent ";
                strSQL += "GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "UNION ALL SELECT 'BU All', 'BU All', 'All BU'";
                strSQL += "UNION ALL SELECT 'BU All', 'BU All', 'Unknown'";
            }
            else if (sRole.IndexOf("ALL") > 0)
            {
                sTradeCluster = "BU_" + sRole.Substring(0, sRole.IndexOf("_"));

                strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]  T1 ";
                strSQL += "INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract] T2 ON T1.Parent = T2.Child AND T2.Distance = 0 ";
                strSQL += "WHERE T2.Parent like '" + sTradeCluster + "%' AND T2.Child = T1.Parent ";
                strSQL += "GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "UNION ALL SELECT 'BU All', 'BU All', 'Unknown'";
            }
            else
            {
                
                if (sRole.IndexOf("_") > 0)
                {
                    sTrade = sRole.Substring(0,sRole.IndexOf("_"));
                }

               strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS TradeCluster, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]  T1 ";
                strSQL += "INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract] T2 ON T1.Parent = T2.Child AND T2.Distance = 1 ";
                strSQL += "WHERE T1.Parent like '" + sTradeCluster + "%' and  T2.Parent like '%" + sTrade + "%' AND T2.Child = T1.Parent ";
                strSQL += "GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "UNION ALL SELECT 'BU All', 'BU All', 'Unknown'";
            }
            return strSQL;
        }


        /// <summary>
        /// Return SQL query for specific role, trade cluster for Dimension String
        /// </summary>
        /// <param name="sRole"></param>
        /// <param name="sTradeCluster"></param>
        /// <param name="sCube"></param>
        /// <returns></returns>
        private string GetSqlQueryForTradeDimensionMarket(string sRole, string sTradeCluster, string sCube)
        {
            string strSQL = String.Empty;
            if (sRole == "FBR_SUPERUSER" || sRole == "ALL_STRINGS" || sRole == "FBR_DEVELOPER" || sRole == "FBR_SERVICE")
            {
                sTradeCluster = "ALL TC";

                strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Trade]  T1 ";
                strSQL += "INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Trade] T2 ON T1.Parent = T2.Child AND T2.Distance = 1 ";
                strSQL += "WHERE T2.Parent like '" + sTradeCluster + "' AND T2.Child = T1.Parent ";
                strSQL += "GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "UNION ALL SELECT 'ML and SCL', 'ML and SCL', 'ML and SCL' ";
                strSQL += "UNION ALL SELECT 'ALL TC', 'ALL TC', 'ALL TC' ";
                strSQL += "UNION ALL SELECT 'ALL TC', 'ALL TC', 'Unknown' ";
            }
            else if (sRole.IndexOf("ALL") > 0)
            {
                string companyName = sRole.Substring(0, sRole.IndexOf("_"));

                sTradeCluster = "BU_" + companyName;

                strSQL = " SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2,T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]	 T1 ";
                strSQL += "  INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]	 T2 ON T1.Parent = T2.Child AND T2.Distance = 0";
                strSQL += "  WHERE T2.Parent like '" + sTradeCluster + "' AND T2.Child = T1.Parent and T1.Child like 'Trade%'";
                strSQL += "  GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += "  UNION ALL SELECT 'ALL TC', 'ALL TC', 'Unknown' ";

                strSQL += "  UNION ALL SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, substring(T1.Child,1,LEN(t1.child)-(SELECT distinct LEN(Company_id) FROM [FBR_DSA_VODKA].[dbo].[Business_Unit] WHERE Name = '" + companyName + "' )) AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]  T1 ";
                strSQL += "  INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract] T2 ON T1.Parent = T2.Child AND T2.Distance = 0";
                strSQL += "  WHERE T2.Parent like '" + sTradeCluster + "' AND T2.Child = T1.Parent and T1.Child like 'Trade%'";
                strSQL += "  GROUP BY T2.Parent,T1.PArent, T1.Child ";

                strSQL += " UNION ALL SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, CONCAT('C',substring(T1.Child,1,LEN(t1.child)-(SELECT distinct LEN(Company_id) FROM [FBR_DSA_VODKA].[dbo].[Business_Unit] WHERE Name = '" + companyName + "' ))) AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]  T1 ";
                strSQL += " INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract] T2 ON T1.Parent = T2.Child AND T2.Distance = 0";
                strSQL += "  WHERE T2.Parent like '" + sTradeCluster + "' AND T2.Child = T1.Parent and T1.Child like 'Trade%'";
                strSQL += "  GROUP BY T2.Parent,T1.PArent, T1.Child ";

                strSQL += "  UNION ALL SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, T3.Parent AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract]  T1 ";
                strSQL += " INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_TradeContract] T2 ON T1.Parent = T2.Child AND T2.Distance = 0";
                strSQL += "  INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Trade] T3 ON  substring(T1.Child,1,LEN(t1.child)-(SELECT distinct LEN(Company_id) FROM [FBR_DSA_VODKA].[dbo].[Business_Unit] WHERE Name = '" + companyName + "' )) = T3.Child";
                strSQL += "   WHERE T2.Parent like '" + sTradeCluster + "' AND T2.Child = T1.Parent and T1.Child like 'TC%'";
                strSQL += "   GROUP BY T2.Parent,T1.PArent,  T3.Parent ";

            }
            else
            {
                if (sRole.IndexOf("_") > 0)
                {
                    sTradeCluster = sRole.Substring(sRole.IndexOf("_") + 1, 3);
                }

                strSQL = "SELECT T2.Parent AS BusinessUnit,T1.Parent AS BusinessUnit2, T1.Child AS String FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Trade] T1 ";
                strSQL += " INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Trade] T2 ON T1.Parent = T2.Child AND T2.Distance = 0 ";
                strSQL += " WHERE (T2.Parent like '%TC_" + sTradeCluster + "%' or T1.Child like '%Trade_" + sTradeCluster + "%') and (T1.Parent = 'ALL TC' or T1.Parent = 'ML and SCL' or T1.Parent like 'TC_%') ";
                strSQL += " GROUP BY T2.Parent,T1.PArent, T1.Child ";
                strSQL += " UNION ALL SELECT 'ALL TC', 'ALL TC', 'Unknown' ";
            }
            return strSQL;
        }


        /// <summary>
        /// Return SQL query for specific BU for dimension Vessel
        /// </summary>
        /// <param name="businessUnit"></param>
        /// <returns></returns>
        private string GetSqlQueryForVesselDimension(string sRole)
        {
            string strSQL = String.Empty;
            //Populating the internal user list based on business unit code

            if (sRole == "FBR_SUPERUSER" || sRole == "ALL_STRINGS" || sRole == "FBR_DEVELOPER" || sRole == "FBR_SERVICE")
            {
                strSQL = "SELECT T1.Child as Vessel";
                strSQL += " FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Vessel]  T1";
                strSQL += " INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Vessel] T2 ON T1.Parent = T2.Child AND T2.Distance = 1";
                strSQL += " INNER JOIN PM_Dim_PC_Vessel T3 on T1.Child = T3.Element";
                strSQL += " WHERE T2.Child = T1.Parent";
                strSQL += " GROUP BY T2.Parent,T1.PArent, T1.Child,T3.VESSELCODE";
                strSQL += " UNION ALL SELECT 'All Vessels'";
            }
            else
            {
                string businessUnit = sRole.Substring(0, sRole.IndexOf("_"));

                if (sRole.IndexOf("ADJUST") > 0)
                {
                    businessUnit = sRole.Substring(sRole.IndexOf("_") + 1);
                    businessUnit = businessUnit.Substring(businessUnit.IndexOf("_") + 1);
                }

                if (String.Compare(businessUnit, "Unknown") == 0)
                {
                    strSQL = "SELECT T1.Child as Vessel";
                    strSQL += " FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Vessel]  T1";
                    strSQL += " INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Vessel] T2 ON T1.Parent = T2.Child AND T2.Distance = 1";
                    strSQL += " INNER JOIN PM_Dim_PC_Vessel T3 on T1.Child = T3.Element";
                    strSQL += " WHERE (T1.Parent like 'OTH%' or T1.Parent like 'MSC%' or T1.Parent like 'Unknown Operator%') AND T2.Child = T1.Parent";
                    strSQL += " GROUP BY T2.Parent,T1.PArent, T1.Child,T3.VESSELCODE";
                }
                else
                {
                    string vesselOperatorCode = "OTH";

                    if (OperatorMapping.Contains(businessUnit))
                    {
                        vesselOperatorCode = OperatorMapping[businessUnit].ToString();
                    }

                    strSQL = "SELECT T1.Child as Vessel";
                    strSQL += " FROM [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Vessel]  T1";
                    strSQL += " INNER JOIN [FBR_DSA_Transfer].[dbo].[PM_Dim_PCH_Vessel] T2 ON T1.Parent = T2.Child AND T2.Distance = 1";
                    strSQL += " INNER JOIN PM_Dim_PC_Vessel T3 on T1.Child = T3.Element";
                    strSQL += " WHERE (T1.Parent like '" + vesselOperatorCode + "%' or T1.Parent like 'Unknown Operator%') AND T2.Child = T1.Parent";
                    strSQL += " GROUP BY T2.Parent,T1.PArent, T1.Child,T3.VESSELCODE";
                }
            }

            return strSQL;
        }

    }
}
