using System;
using System.Collections.Specialized;
using System.Text;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;

namespace COSManager
{
    /// <summary>
    /// This class is a helper class to store user information.
    /// </summary>
    public class Person
    {
        public string Name { get; set; }
        public string UserID { get; set; }
        public List<UserGroup> UserGroups { get; set; }
        public string UserSid { get; set; }
        public string Company { get; set; }
        public string Country { get; set; }
        public string Department { get; set; }
    }
}
