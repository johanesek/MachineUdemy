using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.Security;
using Teradata.Client.Provider;

namespace COSManager
{
    /// <summary>
    /// This class is a layer for relational data access.
    /// </summary>
    public class DataLayer
    {
        private DomainQuery _domainQuery;
        private string _sUserName;
        private string _sTableName;
        private string _sRestrictionApp;
        private string _sWhereFunc;
        public ListDictionary RoleMapping { get; set; }
        public ListDictionary CompanyMapping { get; set; }
        public List<string> ReportCatalogRoles { get; set; }
        public List<string> OlapRolesExceptionList { get; set; }
        public int CompanyNumber { get; set; }

        /// <summary>
        /// This is the constructor method.
        /// It's reading some of the application settings into list objects.
        /// </summary>
        public DataLayer()
        {
            _domainQuery = new DomainQuery();
            RoleMapping = new ListDictionary();
            CompanyMapping = new ListDictionary();
            ReportCatalogRoles = new List<string>();
            OlapRolesExceptionList = new List<string>();
            var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
            if (windowsIdentity != null)
            {
                _sUserName = windowsIdentity.Name;
            }

            _sTableName = ConfigurationManager.AppSettings["TeraDataView"];
            string sfuncAccess1 = ConfigurationManager.AppSettings["FIMFuncAccess1"];
            string sfuncAccess2 = ConfigurationManager.AppSettings["FIMFuncAccess2"];
            string enviromentSpecific = ConfigurationManager.AppSettings["Environment"];
            _sRestrictionApp = ConfigurationManager.AppSettings["FIMRestriction"];

            if (enviromentSpecific.Contains("DEV"))
            {
                string listOfUsers = String.Empty;
                Array asTempDev = (ConfigurationManager.AppSettings["DevUsers"].Split(','));
                for (int i = 0; i <= asTempDev.Length - 1; i++)
                {
                    if (listOfUsers.Equals(String.Empty))
                    {
                        listOfUsers = "('" + asTempDev.GetValue(i).ToString();
                    }
                    else
                    {
                        listOfUsers = listOfUsers + "','" + asTempDev.GetValue(i).ToString();
                    }
                }
                listOfUsers = listOfUsers + "')";
                _sWhereFunc = "functionalityaccess = 'MLIT_BIMDM_FBR_001' and Role1 = 'MLIT FBR Developer' and restrictionvalue = 'FBR_APP_FC' and USER1 in " + listOfUsers;
            }
            else
            {
                _sWhereFunc = "FUNCTIONALITYACCESS = '" + sfuncAccess1+ "'";
            }

            Array asTemp = ConfigurationManager.AppSettings["RoleMapping"].Split('|');
            for (int i = 0; i <= asTemp.Length - 1; i++)
            {
                string[] role = asTemp.GetValue(i).ToString().Split('#');
                RoleMapping.Add(role[0], role[1]);
            }

            asTemp = ConfigurationManager.AppSettings["CompanyMapping"].Split('|');
            ArrayList asFBRCompanies = new ArrayList();
            for (int i = 0; i <= asTemp.Length - 1; i++)
            {
                string[] comp = asTemp.GetValue(i).ToString().Split(',');
                CompanyMapping.Add(comp[0], comp[1]);
                if (!asFBRCompanies.Contains(comp[1]))
                    asFBRCompanies.Add(comp[1]);
            }
            CompanyNumber = asFBRCompanies.Count;

            asTemp = (ConfigurationManager.AppSettings["ReportCatalogRoles"].Split(','));
            for (int i = 0; i <= asTemp.Length - 1; i++)
            {
                ReportCatalogRoles.Add(asTemp.GetValue(i).ToString());
            }

            asTemp = (ConfigurationManager.AppSettings["OLAPRolesExceptionList"].Split(','));
            for (int i = 0; i <= asTemp.Length - 1; i++)
            {
                OlapRolesExceptionList.Add(asTemp.GetValue(i).ToString());
            }
        }

        public SqlConnection GetSqlConnection()
        {
            return ConnectionMgr.GetSqlDbConnection(ConfigurationManager.AppSettings["SQLServerUser"], ConfigurationManager.AppSettings["SQLServerPwd"], ConfigurationManager.AppSettings["SQLServerHost"], ConfigurationManager.AppSettings["SQLServerDB"]);
        }

        public TdConnection GetTdConnection()
        {
            return ConnectionMgr.GetTdDbConnection(ConfigurationManager.AppSettings["TeraDataUser"], ConfigurationManager.AppSettings["TeraDataPwd"], ConfigurationManager.AppSettings["TeraDataHost"], ConfigurationManager.AppSettings["TeraDataDB"]);
        }
        /// <summary>
        /// This method is reading the user information from a TeraData table, which itself is being populated based on a FIM extract.
        /// </summary>
        public List<Person> GetUserInformation()
        {
            List<Person> userList = new List<Person>();

            using (TdConnection connSql = GetTdConnection())
            {
                TdCommand insCmd = new TdCommand();
                try
                {
                    //Getting TeraData connection from ConnectionMgr class
                    insCmd.Connection = connSql;

                    if (insCmd.Connection != null)
                    {
                        //Creating the SQL query string
                        string strSql = "select USER1 from " + ConfigurationManager.AppSettings["TeraDataDB"] + "." + _sTableName + " ";
                        strSql += "where " + _sWhereFunc + " ";
                        strSql += "group by USER1";

                        //Executing the SQL query
                        insCmd.CommandText = strSql;
                        TdDataReader oReader = insCmd.ExecuteReader();

                        string ldapFilter = String.Empty;
                        //Populating the internal user list based on the SQL query
                        while (oReader.Read())
                        {
                            string sUserName = oReader[0].ToString();

                            ldapFilter = ldapFilter + _domainQuery.GetLdapFilterUSer(sUserName);
                        }
                        oReader.Close();
                        //Creating new instance of class Person
                        List<Person> myPersons = _domainQuery.GetWindowsUserProperties(ldapFilter);

                        foreach (Person myPerson in myPersons)
                        {
                            //Retrieving basic groups for user
                            myPerson.UserGroups = GetUserRoles(myPerson.UserID);

                            userList.Add(myPerson);
                        }

                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + ex.Message);
                }
                finally
                {
                    //Closing TeraData command
                    insCmd.Dispose();
                }

                connSql.Close();
            }


            return userList;
        }

        /// <summary>
        /// This method is exporting additional user information to a SQL Server table, which is being used afterwards by Application Studio reports.
        /// </summary>
        public void ExportUserData(List<Person> userList)
        {
            using (SqlConnection connSql = GetSqlConnection())
            {
                SqlCommand insCmd = new SqlCommand();
                try
                {
                    //Getting SQL Server connection from ConnectionMgr class
                    insCmd.Connection = connSql;

                    if (insCmd.Connection != null)
                    {
                        //Creating the SQL statement string in order to emptying the export table
                        string sSQL = "TRUNCATE TABLE " + ConfigurationManager.AppSettings["SQLServerDB"] + ".dbo.AppS_UserInformation";
                        //Executing the SQL statement
                        insCmd.CommandText = sSQL;
                        insCmd.ExecuteNonQuery();
                        int i = 0;
                        //Looping through the user list
                        foreach (var item in userList)
                        {
                            Person myPerson = item as Person;
                            if (myPerson == null)
                            {
                                continue;
                            }
                            i++;
                            if (i == 1)
                            {
                                //Creating the SQL statement string in order to insert a single row into the export table
                                sSQL = "INSERT INTO " + ConfigurationManager.AppSettings["SQLServerDB"] + ".dbo.AppS_UserInformation";
                                sSQL += "(UserId, UserName, Company, Country, Department) VALUES(";
                                sSQL += "'" + myPerson.UserID + "',";
                                sSQL += "'" + myPerson.Name + "',";
                                sSQL += "'" + myPerson.Company + "',";
                                sSQL += "'" + myPerson.Country + "',";
                                sSQL += "'" + myPerson.Department + "')";
                            }
                            else
                            {
                                if (i > 995)
                                {
                                    //Creating the SQL statement string in order to insert a single row into the export table
                                    sSQL += ",(";
                                    sSQL += "'" + myPerson.UserID + "',";
                                    sSQL += "'" + myPerson.Name + "',";
                                    sSQL += "'" + myPerson.Company + "',";
                                    sSQL += "'" + myPerson.Country + "',";
                                    sSQL += "'" + myPerson.Department + "')";

                                    //Executing the SQL statement
                                    insCmd.CommandText = sSQL;
                                    insCmd.ExecuteNonQuery();
                                    i = 0;
                                    sSQL = String.Empty;
                                }
                                else
                                {
                                    //Creating the SQL statement string in order to insert a single row into the export table
                                    sSQL += ",(";
                                    sSQL += "'" + myPerson.UserID + "',";
                                    sSQL += "'" + myPerson.Name + "',";
                                    sSQL += "'" + myPerson.Company + "',";
                                    sSQL += "'" + myPerson.Country + "',";
                                    sSQL += "'" + myPerson.Department + "')";
                                }
                            }
                        }

                        if (i > 0)
                        {
                            //Executing the SQL statement
                            insCmd.CommandText = sSQL;
                            insCmd.ExecuteNonQuery();
                            i = 0;
                            sSQL = String.Empty;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + "Exporting user data to SQL Server failed.");
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + ex.Message);
                }
                finally
                {
                    //Closing the SQL Server command
                    insCmd.Dispose();
                }
                connSql.Close();
            }
        }

        /// <summary>
        /// This method is exporting FIM data to a SQL Server table, which is being used afterwards to populate dimension access cubes in OLAP Server.
        /// </summary>
        public void ExportFIMData()
        {
            using (TdConnection connTd = GetTdConnection())
            {
                TdCommand insCmdTd = new TdCommand();
                using (SqlConnection connSql = GetSqlConnection())
                {
                    SqlCommand insCmdSQL = new SqlCommand();
                    try
                    {
                        //Getting TeraData connection from ConnectionMgr class
                        insCmdTd.Connection = connTd;

                        if (insCmdTd.Connection != null)
                        {
                            //Getting SQL Server connection from ConnectionMgr class
                            insCmdSQL.Connection = connSql;

                            if (insCmdSQL.Connection != null)
                            {
                                //Creating the SQL statement string in order to emptying the export table
                                string sSQL = "TRUNCATE TABLE " + ConfigurationManager.AppSettings["SQLServerDB"] + ".dbo.PM_Adm_FIMUserPermissions";
                                //Executing the SQL statement
                                insCmdSQL.CommandText = sSQL;
                                insCmdSQL.ExecuteNonQuery();

                                //Creating the SQL query string
                                string strSQL = "select USER1, ROLE1, DIMENSION, ";
                                strSQL += "CASE WHEN RESTRICTIONVALUE='" + _sRestrictionApp + "' THEN '*' WHEN RESTRICTIONVALUE='Hamburg S�d' THEN 'Hamburg Sud' ELSE RESTRICTIONVALUE END as RESTRICTIONVALUE, ";
                                strSQL += "VALID_FROM_DTTM, VALID_TO_DTTM from " + ConfigurationManager.AppSettings["TeraDataDB"] + "." + _sTableName + " ";
                                strSQL += "where " + _sWhereFunc + " ";
                                strSQL += "order by FUNCTIONALITYACCESS, USER1, ROLE1, DIMENSION";

                                //Executing the SQL query
                                insCmdTd.CommandText = strSQL;
                                TdDataReader oReader = insCmdTd.ExecuteReader();

                                int i = 0;
                                //Populating the internal user list based on the SQL query
                                while (oReader.Read())
                                {
                                    i++;
                                    if (i == 1)
                                    {
                                        DateTime dtFrom = DateTime.Parse(oReader[4].ToString());
                                        DateTime dtTo = DateTime.Parse(oReader[5].ToString());
                                        //Creating the SQL statement string in order to insert a single row into the export table
                                        sSQL = "INSERT INTO " + ConfigurationManager.AppSettings["SQLServerDB"] + ".dbo.PM_Adm_FIMUserPermissions";
                                        sSQL += "(UserId, FIMRole, Restriction, RestrictionValue, ValidFrom, ValidTo) VALUES(";
                                        sSQL += "'" + oReader[0].ToString() + "',";
                                        sSQL += "'" + oReader[1].ToString() + "',";
                                        sSQL += "'" + oReader[2].ToString() + "',";
                                        sSQL += "'" + oReader[3].ToString() + "',";
                                        sSQL += "'" + dtFrom.ToString("s") + "',";
                                        sSQL += "'" + dtTo.ToString("s") + "')";
                                    }
                                    else
                                    {
                                        if (i > 995)
                                        {
                                            DateTime dtFrom = DateTime.Parse(oReader[4].ToString());
                                            DateTime dtTo = DateTime.Parse(oReader[5].ToString());
                                            //Creating the SQL statement string in order to insert a single row into the export table
                                            sSQL += ",(";
                                            sSQL += "'" + oReader[0].ToString() + "',";
                                            sSQL += "'" + oReader[1].ToString() + "',";
                                            sSQL += "'" + oReader[2].ToString() + "',";
                                            sSQL += "'" + oReader[3].ToString() + "',";
                                            sSQL += "'" + dtFrom.ToString("s") + "',";
                                            sSQL += "'" + dtTo.ToString("s") + "')";

                                            //Executing the SQL statement
                                            insCmdSQL.CommandText = sSQL;
                                            insCmdSQL.ExecuteNonQuery();

                                            i = 0;
                                            sSQL = String.Empty;
                                        }
                                        else
                                        {
                                            DateTime dtFrom = DateTime.Parse(oReader[4].ToString());
                                            DateTime dtTo = DateTime.Parse(oReader[5].ToString());
                                            //Creating the SQL statement string in order to insert a single row into the export table
                                            sSQL += ",(";
                                            sSQL += "'" + oReader[0].ToString() + "',";
                                            sSQL += "'" + oReader[1].ToString() + "',";
                                            sSQL += "'" + oReader[2].ToString() + "',";
                                            sSQL += "'" + oReader[3].ToString() + "',";
                                            sSQL += "'" + dtFrom.ToString("s") + "',";
                                            sSQL += "'" + dtTo.ToString("s") + "')";
                                        }
                                    }
                                }

                                if (i > 0)
                                {
                                    //Executing the SQL statement
                                    insCmdSQL.CommandText = sSQL;
                                    insCmdSQL.ExecuteNonQuery();
                                    i = 0;
                                    sSQL = String.Empty;
                                }
                                oReader.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + "Exporting FIM data to SQL Server failed.");
                        Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + ex.Message);
                    }
                    finally
                    {
                        //Closing the SQL Server command
                        insCmdSQL.Dispose();

                        //Closing the TeraData command
                        insCmdTd.Dispose();
                    }
                    connSql.Close();
                    connTd.Close();
                }
            }
        }

        /// <summary>
        /// This method is reading the user restriction information from a TeraData table, which itself is being populated based on a FIM extract.
        /// Restrictions are based on business units/companies and trade clusters.
        /// </summary>
        public List<string> GetUserRestriction(string strUser, string strRestrictionName, string strRole)
        {
            //Creating of internal list for restrictions, which is handed back by function
            List<string> restrictionList = new List<string>();
            using (TdConnection connTd = GetTdConnection())
            {
                TdCommand insCmd = new TdCommand();
                try
                {
                    //Existing TeraData connection is being used
                    insCmd.Connection = connTd;

                    if (insCmd.Connection != null)
                    {

                        //Preparing the SQL query in order to read restriction values
                        string strSQL = "select ";
                        strSQL += "CASE WHEN RESTRICTIONVALUE='" + _sRestrictionApp + "' THEN '*' WHEN RESTRICTIONVALUE='Hamburg S�d' THEN 'Hamburg Sud'  ELSE RESTRICTIONVALUE END as RestrictionValue ";
                        strSQL += "from " + ConfigurationManager.AppSettings["TeraDataDB"] + "." + _sTableName + " ";
                        strSQL += "where (" + _sWhereFunc + ") ";
                        strSQL += "and User1 = '" + strUser + "' and Dimension = '" + strRestrictionName + "' and Role1 = '" + strRole + "'";
                        strSQL += "group by RestrictionValue";

                        //Executing the SQL query
                        insCmd.CommandText = strSQL;
                        TdDataReader oReader = insCmd.ExecuteReader();

                        //Looping through the result set
                        while (oReader.Read())
                        {
                            //Populate restriction list based on restriction type, which is either StringCompany or TradeCluster
                            switch (strRestrictionName)
                            {
                                case "StringCompany":
                                    if (oReader[0].ToString() == "*")
                                    {
                                        //If StringCompany is "*", then add all business units to list
                                        foreach (string strCompany in CompanyMapping.Values)
                                        {
                                            if (!restrictionList.Contains(strCompany))
                                                restrictionList.Add(strCompany);
                                        }
                                    }
                                    else
                                    {
                                        //Add only the given business unit to list
                                        if (CompanyMapping.Contains(oReader[0].ToString()) && !restrictionList.Contains(CompanyMapping[oReader[0].ToString()].ToString()))
                                            restrictionList.Add(CompanyMapping[oReader[0].ToString()].ToString());
                                    };
                                    break;
                                case "TradeCluster":
                                    if (oReader[0].ToString() == "*")
                                    {
                                        //If TradeCluster is "*", then add "ALL" to list
                                        restrictionList.Add("ALL");
                                    }
                                    else
                                    {
                                        //Add only the given trade cluster to list
                                        if (!restrictionList.Contains(oReader[0].ToString()))
                                            restrictionList.Add(oReader[0].ToString());
                                    };
                                    break;
                            }
                        }
                        oReader.Close();
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + "Retrieving restriction " + strRestrictionName + " for user " + strUser + " failed: " + ex.Message);
                    restrictionList = null;
                }
                finally
                {
                    insCmd.Dispose();
                }
                connTd.Close();
            }
            //Handing back of restriction list
            return restrictionList;
        }

        /// <summary>
        /// This method is reading the user roles from a TeraData table, which itself is being populated based on a FIM extract.
        /// </summary>
        public List<UserGroup> GetUserRoles(string strUser)
        {
            //Creating of internal list for roles, which is handed back by function
            List<UserGroup> roleList = new List<UserGroup>();

            using (TdConnection connTd = GetTdConnection())
            {
                TdCommand insCmd = new TdCommand();
                try
                {
                    //Existing TeraData connection is being used
                    insCmd.Connection = connTd;

                    if (insCmd.Connection != null)
                    {

                        //Preparing the SQL query in order to read roles
                        string strSQL = "select Role1 from " + ConfigurationManager.AppSettings["TeraDataDB"] + "." + _sTableName + " ";
                        strSQL += "where (" + _sWhereFunc + ") ";
                        strSQL += "and User1 = '" + strUser + "' ";
                        strSQL += "group by Role1";

                        //Executing the SQL query
                        insCmd.CommandText = strSQL;
                        TdDataReader oReader = insCmd.ExecuteReader();

                        //Looping through the result set
                        while (oReader.Read())
                        {
                            //Creating new instance of UserGroup class
                            UserGroup userGroup = new UserGroup(oReader[0].ToString());

                            userGroup.Companies = GetUserRestriction(strUser, "StringCompany", userGroup.Name);
                            userGroup.TradeCluster = GetUserRestriction(strUser, "TradeCluster", userGroup.Name);

                            //Adding instance of UserGroup class to role list
                            if (!roleList.Any(p => p.Name == userGroup.Name))
                            {
                                roleList.Add(userGroup);
                            }
                        }
                        oReader.Close();
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + "Retrieving roles for user " + strUser + " failed: " + ex.Message);
                    roleList = null;
                }
                finally
                {
                    insCmd.Dispose();
                }
                connTd.Close();
            }
            //Handing back of restriction list
            return roleList;
        }
    }
}
