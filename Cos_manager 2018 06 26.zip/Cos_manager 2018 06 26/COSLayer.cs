using System;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Collections.Generic;
using Mis_DWCore_ComTree60;
using System.Security.Principal;
using System.Linq;
namespace COSManager
{
    /// <summary>
    /// This class is a layer for Repository access.
    /// </summary>
    public class COSLayer
    {
        private Mis_DWCore_ComTree60.Root _oRoot;
        private List<Person> _userList;
        private Alea _oAlea;
        private Project _oProject;
        //private  _oReporting;
        private ListDictionary _roleList;
        private string _sUserName;
        private List<string> _reportCatalogRoles;
        private int _companyNumber;
        public List<string> NewOlapRoles { get; set; }
        public List<string> OlapRoles { get; set; }

        /// <summary>
        /// This constructor method creates a new instance of class COSLayer and initializes internal properties.
        /// </summary>
        public COSLayer(List<Person> userList, ListDictionary roleList, List<string> reportCatalogRoles, int companyNumber)
        {
            //Initializing internal properties			
            _userList = userList;
            _roleList = roleList;
            _reportCatalogRoles = reportCatalogRoles;
            var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
            if (windowsIdentity != null)
            {
                _sUserName = windowsIdentity.Name;
            }
            NewOlapRoles = new List<string>();
            OlapRoles = new List<string>();
            _companyNumber = companyNumber;
        }

        /// <summary>
        /// This method establishs a connection to Repository.
        /// </summary>
        public bool Connect()
        {
            bool bRet = false;

            try
            {
                //Creating of new Root instance of Repository API
                _oRoot = new Root();
                //Logging into Repository
                String repo = ConfigurationManager.AppSettings["COSDB"];
                String repoUser = ConfigurationManager.AppSettings["COSUser"];
                String repoPW = ConfigurationManager.AppSettings["COSPwd"];

                _oRoot.ApplicationPath = ConfigurationManager.AppSettings["dllFilesPath"];

                bRet = _oRoot.LoginBasic(repo, repoUser, repoPW);

                //Initializing instance of OLAP permission management class
                _oProject = _oRoot.Projects.ItemByName(ConfigurationManager.AppSettings["COSProject"]);
                _oAlea = _oProject.Aleas.ItemByName(ConfigurationManager.AppSettings["OLAPPM"]);

                foreach (AleaRole t in _oAlea.AleaRoles)
                {
                    OlapRoles.Add(t.Name);
                }

                //Initializing instance of Reporting class

                //_oReporting = _oProject.UpgradeVersion.[ConfigurationManager.AppSettings["ReportCatalog"]];
            }
            catch (Exception ex)
            {
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, ex.Message);
                bRet = false;
            }
            return bRet;
        }

        /// <summary>
        /// This method closes a Repository connection.
        /// </summary>
        public bool Disconnect()
        {
            bool bRet = _oRoot.Logout();
            return bRet;
        }

        public void RefreshMGMTAdjustRolesRoles(ListDictionary companyMapping)
        {
            foreach (string item in companyMapping.Values)
            {
                if (!_oRoot.SsoManagement.ManualGroups.ContainsName("MGMT_ADJUST_" + item))
                {
                    try
                    {
                        SsoManualGroup grp = _oRoot.SsoManagement.ManualGroups.Add();
                        grp.Name = "MGMT_ADJUST_" + item;
                        grp.Description = "User in this group can use delete all on the relational adjustment report";

                        grp.Checkin(true);
                        _oRoot.SsoManagement.ManualGroups.Refresh(true);
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now + "\t" + _sUserName + "\t" + ex.Message);
                    }
                }
            }
        }

        /// <summary>
        /// This method registers Windows single-sign-on users in Repository.
        /// </summary>
        public void CreateSSOUser()
        {
            //retreive the sso provider GUID
            String repo = ConfigurationManager.AppSettings["COSDB"];
            SsoProvider sso = _oRoot.SsoManagement.Providers.Item(0);
            string customSsoProvider = String.Empty;
            customSsoProvider = sso.SSOType;
            //Creating SSO entries
            foreach (Person t in _userList)
            {
                //Creating new instance for Windows user (custom user in Repository terminology)
                SsoCustomUser myUser = _oRoot.SsoManagement.CustomUsers.Add();
                myUser.Name = ConfigurationManager.AppSettings["WindowsDomain"] + @"\" + t.UserID;
                myUser.Description = t.Name;
                myUser.Identifier = t.UserSid;
                myUser.SSOType = customSsoProvider;

                myUser.Checkin(true);

                _oRoot.SsoManagement.TransferAuthenticationObjectsToAuthorization();

                if ((COSManager.Person)t == null)
                {
                    continue;
                }

                List<UserGroup> groups = t.UserGroups;
                //Assigning user management basic groups to current Windows user
                if (groups == null)
                {
                    continue;
                }

                foreach (UserGroup userGroup in groups)
                {
                    if (String.Compare(userGroup.Name, String.Empty) != 0)
                    {
                        //Finding Repository basic group
                        if (_roleList[userGroup.Name] == null)
                        {
                            continue;
                        }

                        string strManualGroup = _roleList[userGroup.Name].ToString();

                        if (String.Compare(strManualGroup.Trim(), String.Empty) != 0)
                        {
                            string guidManualGroup = _oRoot.SsoManagement.ManualGroups.ItemByName(strManualGroup).ID;

                            //Check, whether user group already exists
                            bool bExisting = false;
                            foreach (var item in myUser.SsoCustomUserManualGroups)
                            {
                                SsoCustomUserManualGroup manualGroup = item as SsoCustomUserManualGroup;
                                if (manualGroup != null && manualGroup.SsoManualGroup.ID == guidManualGroup)
                                {
                                    bExisting = true;
                                    break;
                                }
                            }
                            //If user groups exists, assign Windows user to it
                            if (!bExisting)
                            {
                                //Creating new instance of basis group and assign Windows user
                                SsoCustomUserManualGroup oGroup = myUser.SsoCustomUserManualGroups.Add();
                                oGroup.SsoCustomUser = myUser;
                                oGroup.SsoManualGroup = _oRoot.SsoManagement.ManualGroups.ItemByName(strManualGroup);
                                oGroup.CheckinRecursive(true);
                            }
                        }
                    }

                    //If Windows user is additionally in adjustment role, then assign him to the company-specific basic group
                    if (userGroup.Name.IndexOf("Adjustment") > 0)
                    {
                        for (int j = 0; j <= userGroup.Companies.Count - 1; j++)
                        {
                            //Assigning Windows user to basic group

                            string guidManualGroup = _oRoot.SsoManagement.ManualGroups.ItemByName("MGMT_ADJUST_" + userGroup.Companies[j]).ID;

                            //Check, whether user group already exists
                            bool bExisting = false;
                            foreach (var item in myUser.SsoCustomUserManualGroups)
                            {
                                SsoCustomUserManualGroup manualGroup = item as SsoCustomUserManualGroup;
                                if (manualGroup != null && manualGroup.SsoManualGroup.ID == guidManualGroup)
                                {
                                    bExisting = true;
                                    break;
                                }
                            }
                            //If user groups exists, assign Windows user to it
                            if (!bExisting)
                            {
                                //Creating new instance of basis group and assign Windows user
                                SsoCustomUserManualGroup oGroup = myUser.SsoCustomUserManualGroups.Add();
                                oGroup.SsoCustomUser = myUser;
                                oGroup.SsoManualGroup = _oRoot.SsoManagement.ManualGroups.ItemByName("MGMT_ADJUST_" + userGroup.Companies[j]);
                                oGroup.CheckinRecursive(true);
                            }
                        }
                    }
                }
            }

            _oRoot.SsoManagement.CustomUsers.Refresh(true);
        }

        /// <summary>
        /// This method removes all Windows user entries from user management of Repository.
        /// </summary>
        public void DeleteSSOUser()
        {
            string sLogText = String.Empty;

            //Removing all Windows users from user management
            foreach (SsoCustomUser t in _oRoot.SsoManagement.CustomUsers)
            {
                try
                {
                    sLogText = "ERROR: Removing of SSO Windows user " + t.Name + " failed.";

                    if (!t.IsDeleted)
                    {
                        t.CheckoutRecursive(true, true);
                        t.DeleteRecursive(true);
                        t.CheckinRecursive(true);
                    }
                }
                catch (MemberAccessException ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now + "\t" + _sUserName + "\t" + sLogText + "\t" + ex.Message);
                }
            }

            _oRoot.SsoManagement.CustomUsers.Refresh(true);
            _oRoot.SsoManagement.ManualUsers.Refresh(true);

            _oRoot.SsoManagement.TransferAuthenticationObjectsToAuthorization();
            //Emptying trashcan
            SsoCustomUsers customUsers = _oRoot.SsoManagement.CustomUsers.Trashcan();
            if (customUsers != null)
            {
                foreach (SsoCustomUser customUser in customUsers)
                {
                    try
                    {
                        sLogText = "ERROR: Removing of SSO trashcan entry for user " + customUser.Name + " failed.";

                        customUser.CheckinRecursive(true);
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now + "\t" + _sUserName + "\t" + sLogText + "\t" + ex.Message);
                    }
                }
            }
        }

        /// <summary>
        /// This method removes all generic OLAP roles from Repository.
        /// This is currently not used.
        /// </summary>
        public void DeleteGenericRoles()
        {
            string[] userTypeArray = ConfigurationManager.AppSettings["UserType"].Split(new char[] { ';' });

            foreach (string t in userTypeArray.Where(t => _oAlea.AleaRoles.ContainsName(t.Split(new char[] { ',' })[1])))
            {
                try
                {
                    _oAlea.AleaRoles.ItemByName(t.Split(new char[] { ',' })[1]).CheckoutRecursive(true, true);
                    _oAlea.AleaRoles.ItemByName(t.Split(new char[] { ',' })[1]).DeleteRecursive(true);
                }
                catch (MemberAccessException ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, ex.Message);
                }
            }

            AleaRoles deletedRoles = _oAlea.AleaRoles.Trashcan();
            if (deletedRoles != null)
            {
                foreach (AleaRole role in deletedRoles)
                {
                    role.CheckinRecursive(true);
                }
            }
        }

        /// <summary>
        /// This method creates OLAP roles for every SSO user in Repository.
        /// This is currently not used.
        /// </summary>
        public void CreateAleaRoles()
        {
            string sLogText = String.Empty;

            //create OLAP permission management entries
            _oRoot.SsoManagement.TransferAuthenticationObjectsToAuthorization();

            _oRoot.AuthorizationObjects.Refresh(true);

            //create string specific roles
            foreach (Person t in _userList)
            {
                try
                {
                    foreach (UserGroup oUserGroup in t.UserGroups)
                    {
                        foreach (string t2 in oUserGroup.TradeCluster)
                        {
                            foreach (string t3 in oUserGroup.Companies)
                            {
                                string sOLAPRole = t3 + "_" + t2;

                                //add role for company+tradecluster
                                if (!_oAlea.AleaRoles.ContainsName(sOLAPRole))
                                {
                                    sLogText = "ERROR: Creation of OLAP role " + sOLAPRole + " failed.";
                                    AleaRole myRole = _oAlea.AleaRoles.Add();
                                    myRole.Name = sOLAPRole;
                                    myRole.Description = "BU " + t3 + ", " + "TC " + t2 + " (WRITE)";
                                    myRole.CheckinRecursive(true);

                                    NewOlapRoles.Add(myRole.Name);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + sLogText + "\t" + ex.Message);
                }
            }
        }

        /// <summary>
        /// This method assigns OLAP permissions to OLAP roles in Repository.
        /// This is currently not used.
        /// </summary>
        public void AssignPermissions()
        {
            foreach (string sOLAPRole in NewOlapRoles)
            {
                AleaRole role = _oAlea.AleaRoles.ItemByName(sOLAPRole);

                try
                {
                    Permission perm = _oRoot.Permissions.ItemByName("View");
                    AleaRolePermission roleperm;
                    if (!role.AleaRolePermissions.Contains(perm.ID))
                    {
                        role.CheckoutRecursive(true, true);
                        roleperm = role.AleaRolePermissions.Add();
                        roleperm.Permission = perm;
                        role.CheckinRecursive(true);
                    }

                    perm = _oRoot.Permissions.ItemByName("Import/export values");
                    if (!role.AleaRolePermissions.Contains(perm.ID))
                    {
                        role.CheckoutRecursive(true, true);
                        roleperm = role.AleaRolePermissions.Add();
                        roleperm.Permission = perm;
                        role.CheckinRecursive(true);
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + ex.Message);
                }
            }
        }

        /// <summary>
        /// This method assigns Windows users to report catalog roles in Repository.
        /// This is currently not used.
        /// </summary>
        //public void AssignReportCatalogRoles()
        //{
        //    string sLogText = String.Empty;

        //    //create Report catalog entries
        //    _oRoot.SsoManagement.TransferAuthenticationObjectsToAuthorization();

        //    //assign user to roles
        //    foreach (Person t in _userList)
        //    {
        //        try
        //        {
        //            //report catalog role assignment
        //            foreach (UserGroup userGroup in t.UserGroups)
        //            {
        //                if (_reportCatalogRoles.Contains(_roleList[userGroup].ToString()))
        //                {
        //                    //ReportingRole role = _oReporting.ReportingRoles.ItemByName(_roleList[userGroup].ToString());

        //                    ////windows user
        //                    //if (_oRoot.AuthorizationObjects.ContainsName(ConfigurationManager.AppSettings["WindowsDomain"] + "\\" + t.UserID))
        //                    //{
        //                    //    sLogText = "ERROR: Assignment of user " + ConfigurationManager.AppSettings["WindowsDomain"] + "\\" + t.UserID + " to ViewRole failed.";

        //                    //    AuthorizationObject authObj = _oRoot.AuthorizationObjects.ItemByName(ConfigurationManager.AppSettings["WindowsDomain"] + "\\" + t.UserID);
        //                    //    ReportingRoleAuthorizationObject repRoleAuthObj = role.ReportingRoleAuthorizationObjects.Add();
        //                    //    repRoleAuthObj.AuthorizationObject = authObj;
        //                    //    repRoleAuthObj.Checkin(true);
        //                    //}
        //                }
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + sLogText + "\t" + ex.Message);
        //        }
        //    }
        //}


        /// <summary>
        /// This method assigns Windows users to roles in OLAP permission management of Repository.
        /// </summary>
        public void AssignOLAPRoles()
        {
            string sLogText = String.Empty;
            //Refreshing of authentication objects (Windows users) in authorization section of Repository
            _oRoot.SsoManagement.TransferAuthenticationObjectsToAuthorization();
            _oRoot.AuthorizationObjects.Refresh(true);

            //Looping through user list and assigning of OLAP roles
            foreach (Person t in _userList)
            {
                try
                {
                    List<string> rolesAdded = new List<string>();
                    //Looping through all user groups, the user is assigned to (some users may have more than one user group)
                    foreach (UserGroup userGroup in t.UserGroups)
                    {
                        if (userGroup.Name.IndexOf("Reviewer") >= 0 || userGroup.Name.IndexOf("Viewer") >= 0 || userGroup.Name.IndexOf("Bunker Owner") >= 0)
                        {
                            //For every business unit/company assign the respective roles (a user might be assigned to different roles in different business units)
                            for (int j = 0; j <= userGroup.Companies.Count - 1; j++)
                            {
                                string strRoleName = String.Empty;

                                if (userGroup.Name.IndexOf("Bunker Owner") >= 0)
                                {
                                    strRoleName = userGroup.Companies[j].ToString() + "_ALL";
                                    sLogText = "ERROR: Assignment of user " + ConfigurationManager.AppSettings["WindowsDomain"] + "\\" + t.UserID + " to OLAP role " + strRoleName + " failed.";

                                    if (!rolesAdded.Any(p => p == strRoleName))
                                    {
                                        rolesAdded.Add(strRoleName);
                                        AssigneRole(strRoleName, t);
                                    }
                                }
                                else
                                {
                                    //the role being assigned to is depending on the trade cluster, the user is assigned to in FIM
                                    for (int k = 0; k <= userGroup.TradeCluster.Count - 1; k++)
                                    {
                                        //if user is assigned to StringCompany "*" in FIM, then assign him to ALL role
                                        //if (_userGroup.Companies[j].ToString().IndexOf("ALL") >= 0)
                                        if (userGroup.Companies.Count == _companyNumber)
                                        {
                                            if (userGroup.TradeCluster[k].ToString().IndexOf("ALL") >= 0)
                                            {
                                                if (userGroup.Name.IndexOf("Reviewer") >= 0 || userGroup.Name.IndexOf("Viewer") >= 0)
                                                { strRoleName = "ALL_STRINGS"; }
                                            }
                                        }
                                        else
                                        {
                                            if (userGroup.TradeCluster[k].ToString().IndexOf("ALL") >= 0)
                                            {
                                                if (userGroup.Name.IndexOf("Reviewer") >= 0 || userGroup.Name.IndexOf("Viewer") >= 0)
                                                    strRoleName = userGroup.Companies[j].ToString() + "_" + userGroup.TradeCluster[k].ToString();
                                            }
                                            else
                                            {
                                                if (userGroup.Name.IndexOf("Reviewer") >= 0 || userGroup.Name.IndexOf("Viewer") >= 0)
                                                    strRoleName = userGroup.Companies[j].ToString() + "_" + userGroup.TradeCluster[k].ToString();
                                            }
                                        }
                                        sLogText = "ERROR: Assignment of user " + ConfigurationManager.AppSettings["WindowsDomain"] + "\\" + t.UserID + " to OLAP role " + strRoleName + " failed.";


                                        if (!rolesAdded.Any(p => p == strRoleName))
                                        {
                                            rolesAdded.Add(strRoleName);
                                            AssigneRole(strRoleName, t);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + sLogText + "\t" + ex.Message);
                }
            }
        }

        private void AssigneRole(string strRoleName, Person t)
        {
            AleaRoleAuthorizationObject aleaRoleAuthObj = null;
            try
            {
                //Assigning Windows user to OLAP role
                AuthorizationObject authObj = _oRoot.AuthorizationObjects.ItemByName(ConfigurationManager.AppSettings["WindowsDomain"] + "\\" + t.UserID.ToString().ToUpper());
                //Check, whether role exists

                if (_oAlea.AleaRoles.ContainsName(strRoleName))
                {
                    AleaRole myRole = _oAlea.AleaRoles.ItemByName(strRoleName);

                    myRole.Checkout(true);
                    //Check, whether Windows user is already assigned to this role

                    bool bExisting = false;
                    if (myRole.AleaRoleAuthorizationObjects.Count > 0)
                    {
                        try
                        {
                            foreach (var item in myRole.AleaRoleAuthorizationObjects)
                            {
                                AleaRoleAuthorizationObject roleAuthObject = item as AleaRoleAuthorizationObject;
                                if (roleAuthObject != null && roleAuthObject.AuthorizationObject.Name == authObj.Name)
                                {
                                    bExisting = true;
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    //if user isn't yet assigned, assing him to this role
                    if (!bExisting)
                    {
                        aleaRoleAuthObj = myRole.AleaRoleAuthorizationObjects.Add();
                        aleaRoleAuthObj.AuthorizationObject = authObj;
                        aleaRoleAuthObj.Checkin(true);
                        myRole.AleaRoleAuthorizationObjects.Refresh(true);
                        myRole.Checkin(true);
                    }
                    else
                    {
                        myRole.UndoCheckout(true);
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + t.UserID + "\t" + strRoleName + "\t" + ex.Message);
            }
        }

        /// <summary>
        /// This method removes Windows users from roles in OLAP permission management of Repository.
        /// </summary>
        public void DeleteOLAPRoleAssignments()
        {
            string sLogText = String.Empty;

            //Refreshing of authentication objects (Windows users) in authorization section of Repository
            _oRoot.SsoManagement.TransferAuthenticationObjectsToAuthorization();
            _oRoot.AuthorizationObjects.Refresh(true);

            //Looping through all OLAP roles and removing of Windows users
            foreach (AleaRole t in _oAlea.AleaRoles)
            {
                try
                {
                    //Creating of an internal list of OLAP roles
                    int nRoleAuthObjectsNumber = t.AleaRoleAuthorizationObjects.Count;
                    ArrayList rolAuthObjects = new ArrayList();
                    for (int k = 0; k < nRoleAuthObjectsNumber; k++)
                    {
                        rolAuthObjects.Add(t.AleaRoleAuthorizationObjects.Item(k));
                    }

                    //If role is assigned to a Windows user, then remove him
                    for (int j = 0; j < nRoleAuthObjectsNumber; j++)
                    {
                        var rolAuthObject = (AleaRoleAuthorizationObject)rolAuthObjects[j];
                        if (rolAuthObject.AuthorizationObject.AuthorizationObjectType.Name == "WindowsUser")
                        {
                            rolAuthObject.CheckoutRecursive(true, true);
                            rolAuthObject.DeleteRecursive(true);
                            rolAuthObject.CheckinRecursive(true);
                        }
                    }

                    //Emptying trashcan
                    AleaRoleAuthorizationObjects deletedRoleAuthObjects = t.AleaRoleAuthorizationObjects.Trashcan();
                    if (deletedRoleAuthObjects != null)
                    {
                        foreach (AleaRoleAuthorizationObject roleAuthObject in deletedRoleAuthObjects)
                        {
                            try
                            {
                                sLogText = "ERROR: Removing of users from OLAP role " + roleAuthObject.AleaRole.Name + " failed.";

                                roleAuthObject.CheckinRecursive(true);
                            }
                            catch (Exception ex)
                            {
                                Trace.WriteLineIf(Program.TraceEnabled.Enabled, sLogText + "\t" + ex.Message);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLineIf(Program.TraceEnabled.Enabled, System.DateTime.Now.ToString() + "\t" + _sUserName + "\t" + sLogText + "\t" + ex.Message);
                }
            }
        }
    }
}
